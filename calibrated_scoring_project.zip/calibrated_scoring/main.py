"""Train classifiers, calibrate their probabilities, and evaluate calibration.

Run:  python main.py
"""
from src.config import OUTPUT_DIR
from src.data import load_data
from src.experiment import paired_comparison, reliability_bins, run_experiment, summarise
from src.models import base_models
from src.plots import plot_metric_comparison, plot_reliability


def main() -> None:
    OUTPUT_DIR.mkdir(exist_ok=True)
    X, y = load_data()
    print(f"{len(y)} patients, {y.mean():.1%} malignant, {X.shape[1]} features")

    per_run, pooled = run_experiment(X, y)
    summary = summarise(per_run)
    model_names = list(base_models())

    summary.round(4).to_csv(OUTPUT_DIR / "calibration_metrics.csv")
    per_run.to_csv(OUTPUT_DIR / "per_run_metrics.csv", index=False)
    paired_comparison(per_run).round(4).to_csv(OUTPUT_DIR / "paired_comparison.csv", index=False)
    reliability_bins(pooled).round(4).to_csv(OUTPUT_DIR / "reliability_bins.csv", index=False)
    plot_reliability(pooled, model_names, OUTPUT_DIR / "reliability_diagrams.png")
    plot_metric_comparison(summary, model_names, OUTPUT_DIR / "metric_comparison.png")

    print(summary.xs("mean", axis=1, level=1).round(4).to_string())
    print(f"\nSaved figures and metrics to {OUTPUT_DIR}")


if __name__ == "__main__":
    main()
