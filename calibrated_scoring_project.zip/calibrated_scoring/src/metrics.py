"""Calibration metrics."""
import numpy as np
from sklearn.metrics import brier_score_loss, log_loss, roc_auc_score

from .config import N_BINS


def reliability_table(y_true, y_prob, n_bins: int = N_BINS):
    """Per-bin (mean predicted probability, observed frequency, count); empty bins are skipped."""
    y_true, y_prob = np.asarray(y_true), np.asarray(y_prob)
    bin_ids = np.minimum((y_prob * n_bins).astype(int), n_bins - 1)
    counts = np.bincount(bin_ids, minlength=n_bins)
    keep = counts > 0
    mean_pred = np.bincount(bin_ids, weights=y_prob, minlength=n_bins)[keep] / counts[keep]
    observed = np.bincount(bin_ids, weights=y_true, minlength=n_bins)[keep] / counts[keep]
    return mean_pred, observed, counts[keep]


def expected_calibration_error(y_true, y_prob, n_bins: int = N_BINS) -> float:
    """ECE = sum over bins of (bin share of samples) * |observed frequency - mean prediction|."""
    mean_pred, observed, counts = reliability_table(y_true, y_prob, n_bins)
    return float(np.sum(counts / counts.sum() * np.abs(observed - mean_pred)))


def score_probabilities(y_true, y_prob) -> dict:
    eps = 1e-15  # keep log-loss finite when a model outputs exact 0 or 1
    return {
        "ECE": expected_calibration_error(y_true, y_prob),
        "Brier": brier_score_loss(y_true, y_prob),
        "Log loss": log_loss(y_true, np.clip(y_prob, eps, 1 - eps)),
        "ROC-AUC": roc_auc_score(y_true, y_prob),
    }
