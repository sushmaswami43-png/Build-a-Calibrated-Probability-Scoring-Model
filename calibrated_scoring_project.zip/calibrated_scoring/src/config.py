"""Central configuration for the calibration experiment."""
from pathlib import Path

RANDOM_STATE = 42
N_REPEATS = 20        # independent train/test splits (small dataset -> average out split luck)
TEST_SIZE = 0.30
CALIBRATION_CV = 5    # folds used inside the training set to fit the calibrator
N_BINS = 10           # reliability-diagram / ECE bins (equal width)
METHODS = {"Uncalibrated": None, "Platt (sigmoid)": "sigmoid", "Isotonic": "isotonic"}
OUTPUT_DIR = Path(__file__).resolve().parent.parent / "outputs"
