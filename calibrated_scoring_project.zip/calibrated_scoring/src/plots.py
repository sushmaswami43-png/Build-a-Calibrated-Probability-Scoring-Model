"""Figures: reliability diagrams with probability histograms, and a metric comparison."""
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

from .config import METHODS, N_BINS
from .metrics import expected_calibration_error, reliability_table

STYLE = {"Uncalibrated": ("#d62728", "o"), "Platt (sigmoid)": ("#2a6fdb", "s"),
         "Isotonic": ("#2ca02c", "^")}


def plot_reliability(pooled, model_names, path) -> None:
    """Top row: reliability diagrams. Bottom row: histograms of predicted probabilities."""
    n = len(model_names)
    fig, axes = plt.subplots(2, n, figsize=(5 * n, 8), height_ratios=[3, 1.4], sharex="col")
    for col, model in enumerate(model_names):
        ax, hist_ax = axes[0, col], axes[1, col]
        ax.plot([0, 1], [0, 1], "k--", lw=1, label="Perfectly calibrated")
        for variant, (color, marker) in STYLE.items():
            y_true, y_prob = pooled[(model, variant)]
            mean_pred, observed, _ = reliability_table(y_true, y_prob)
            ece = expected_calibration_error(y_true, y_prob)
            ax.plot(mean_pred, observed, marker=marker, color=color, lw=1.6,
                    label=f"{variant} (ECE {ece:.3f})")
            hist_ax.hist(y_prob, bins=np.linspace(0, 1, N_BINS * 2 + 1), histtype="step",
                         color=color, lw=1.6, label=variant)
        ax.set(title=model, ylabel="Observed frequency of malignant", xlim=(0, 1), ylim=(-0.02, 1.02))
        ax.legend(loc="upper left", fontsize=8)
        ax.grid(alpha=0.3)
        hist_ax.set(xlabel="Predicted probability", ylabel="Count", yscale="log")
    fig.suptitle("Reliability diagrams (top) and predicted-probability distributions (bottom)",
                 fontsize=13)
    fig.tight_layout()
    fig.savefig(path, dpi=140)
    plt.close(fig)


def plot_metric_comparison(summary, model_names, path) -> None:
    """Grouped bars (mean +/- std over repeats) of ECE and Brier score."""
    fig, axes = plt.subplots(1, 2, figsize=(11, 4))
    width = 0.26
    for ax, metric in zip(axes, ["ECE", "Brier"]):
        for k, variant in enumerate(METHODS):
            means = [summary.loc[(m, variant), (metric, "mean")] for m in model_names]
            stds = [summary.loc[(m, variant), (metric, "std")] for m in model_names]
            ax.bar(np.arange(len(model_names)) + (k - 1) * width, means, width, yerr=stds,
                   capsize=3, color=STYLE[variant][0], label=variant)
        ax.set_xticks(range(len(model_names)), model_names, fontsize=9)
        ax.set(title=f"{metric} (lower is better)", ylabel=metric)
        ax.grid(axis="y", alpha=0.3)
    axes[0].legend(fontsize=8)
    fig.tight_layout()
    fig.savefig(path, dpi=140)
    plt.close(fig)
