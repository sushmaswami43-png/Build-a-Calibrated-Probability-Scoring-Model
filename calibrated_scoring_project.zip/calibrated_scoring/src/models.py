"""Base classifiers and the calibration wrapper."""
from typing import Optional

from sklearn.base import BaseEstimator, clone
from sklearn.calibration import CalibratedClassifierCV
from sklearn.ensemble import RandomForestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.naive_bayes import GaussianNB
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler

from .config import CALIBRATION_CV, RANDOM_STATE


def base_models() -> dict[str, BaseEstimator]:
    """Three models with different calibration behaviour (linear, tree ensemble, naive Bayes)."""
    return {
        "Logistic Regression": make_pipeline(
            StandardScaler(), LogisticRegression(max_iter=2000, random_state=RANDOM_STATE)),
        "Random Forest": RandomForestClassifier(
            n_estimators=200, random_state=RANDOM_STATE, n_jobs=-1),
        "Gaussian Naive Bayes": GaussianNB(),
    }


def make_variant(model: BaseEstimator, method: Optional[str]) -> BaseEstimator:
    """Return an unfitted copy of `model`, wrapped in a calibrator if `method` is given.

    The calibrator is fitted on out-of-fold predictions from the training data only,
    so the test set never influences calibration.
    """
    model = clone(model)
    if method is None:
        return model
    return CalibratedClassifierCV(model, method=method, cv=CALIBRATION_CV)
