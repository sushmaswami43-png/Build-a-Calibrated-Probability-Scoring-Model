"""Dataset loading."""
import pandas as pd
from sklearn.datasets import load_breast_cancer


def load_data() -> tuple[pd.DataFrame, pd.Series]:
    """Wisconsin Diagnostic Breast Cancer data. Target: 1 = malignant, 0 = benign."""
    raw = load_breast_cancer(as_frame=True)
    return raw.data, (raw.target == 0).astype(int)
