"""Repeated train / calibrate / evaluate loop."""
import numpy as np
import pandas as pd
from sklearn.model_selection import StratifiedShuffleSplit

from .config import METHODS, N_REPEATS, RANDOM_STATE, TEST_SIZE
from .metrics import reliability_table, score_probabilities
from .models import base_models, make_variant


def run_experiment(X: pd.DataFrame, y: pd.Series):
    """Evaluate every (model, calibration) pair on N_REPEATS random stratified splits.

    Returns
    -------
    per_run : DataFrame with one row of metrics per (repeat, model, variant).
    pooled  : {(model, variant): (y_true, y_prob)} concatenated over all test sets,
              used for the reliability diagrams (more points per bin than one split).
    """
    splitter = StratifiedShuffleSplit(N_REPEATS, test_size=TEST_SIZE, random_state=RANDOM_STATE)
    rows, collected = [], {}

    for repeat, (train_idx, test_idx) in enumerate(splitter.split(X, y)):
        X_train, X_test = X.iloc[train_idx], X.iloc[test_idx]
        y_train, y_test = y.iloc[train_idx], y.iloc[test_idx]
        for model_name, model in base_models().items():
            for variant, method in METHODS.items():
                fitted = make_variant(model, method).fit(X_train, y_train)
                y_prob = fitted.predict_proba(X_test)[:, 1]
                rows.append({"repeat": repeat, "model": model_name, "variant": variant,
                             **score_probabilities(y_test, y_prob)})
                collected.setdefault((model_name, variant), []).append((y_test.to_numpy(), y_prob))

    pooled = {key: (np.concatenate([t for t, _ in parts]), np.concatenate([p for _, p in parts]))
              for key, parts in collected.items()}
    return pd.DataFrame(rows), pooled


def summarise(per_run: pd.DataFrame) -> pd.DataFrame:
    """Mean and standard deviation of each metric across repeats."""
    metrics = ["ECE", "Brier", "Log loss", "ROC-AUC"]
    summary = per_run.groupby(["model", "variant"], sort=False)[metrics].agg(["mean", "std"])
    return summary


def paired_comparison(per_run: pd.DataFrame) -> pd.DataFrame:
    """For each calibrator vs. the uncalibrated model: mean change in each metric and the
    number of splits (out of N_REPEATS) in which calibration gave the lower (better) value."""
    rows = []
    for model, group in per_run.groupby("model", sort=False):
        raw = group[group["variant"] == "Uncalibrated"].set_index("repeat")
        for variant in [v for v in METHODS if METHODS[v]]:
            cal = group[group["variant"] == variant].set_index("repeat")
            for metric in ["ECE", "Brier", "Log loss"]:
                diff = cal[metric] - raw[metric]
                rows.append({"model": model, "variant": variant, "metric": metric,
                             "mean_change": diff.mean(), "splits_improved": int((diff < 0).sum())})
    return pd.DataFrame(rows)


def reliability_bins(pooled) -> pd.DataFrame:
    """Pooled reliability-diagram points as a table."""
    rows = []
    for (model, variant), (y_true, y_prob) in pooled.items():
        mean_pred, observed, counts = reliability_table(y_true, y_prob)
        rows += [{"model": model, "variant": variant, "mean_predicted": p, "observed": o, "count": c}
                 for p, o, c in zip(mean_pred, observed, counts)]
    return pd.DataFrame(rows)
