"""Build the assignment report PDF from the experiment outputs (run main.py first)."""
from pathlib import Path

import pandas as pd
from PIL import Image as PILImage
from reportlab.lib import colors
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.lib.units import cm
from reportlab.platypus import (Image, PageBreak, Paragraph, Preformatted,
                                SimpleDocTemplate, Spacer, Table, TableStyle)

ROOT = Path(__file__).parent
OUT = ROOT / "outputs"
S = getSampleStyleSheet()
BODY = ParagraphStyle("body", parent=S["BodyText"], fontSize=10.3, leading=14.5)
SMALL = ParagraphStyle("small", parent=BODY, fontSize=8.8, leading=12, textColor=colors.HexColor("#444444"))
CODE = ParagraphStyle("code", parent=S["Code"], fontSize=7.2, leading=8.6)
CONTENT_WIDTH = 17 * cm


def p(text, style=BODY):
    return Paragraph(text, style)


def bullets(items):
    return [p("&bull; " + t) for t in items]


def figure(name, caption):
    w, h = PILImage.open(OUT / name).size
    return [Image(str(OUT / name), width=CONTENT_WIDTH, height=CONTENT_WIDTH * h / w), p(caption, SMALL)]


def styled_table(data, col_widths=None, highlight_rows=()):
    table = Table(data, colWidths=col_widths, hAlign="LEFT", repeatRows=1)
    style = [("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#2a6fdb")),
             ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
             ("GRID", (0, 0), (-1, -1), 0.4, colors.grey),
             ("FONTSIZE", (0, 0), (-1, -1), 8.6), ("ALIGN", (2, 1), (-1, -1), "CENTER"),
             ("TOPPADDING", (0, 0), (-1, -1), 3.5), ("BOTTOMPADDING", (0, 0), (-1, -1), 3.5)]
    style += [("BACKGROUND", (0, r), (-1, r), colors.HexColor("#eef6ee")) for r in highlight_rows]
    table.setStyle(TableStyle(style))
    return table


def results_table():
    runs = pd.read_csv(OUT / "per_run_metrics.csv")
    agg = runs.groupby(["model", "variant"], sort=False)[["ECE", "Brier", "Log loss", "ROC-AUC"]].agg(["mean", "std"])
    data = [["Model", "Calibration", "ECE", "Brier", "Log loss", "ROC-AUC"]]
    for (model, variant), row in agg.iterrows():
        data.append([model, variant] + [f"{row[(m, 'mean')]:.4f} ({row[(m, 'std')]:.4f})"
                                        for m in ["ECE", "Brier", "Log loss", "ROC-AUC"]])
    return styled_table(data, [3.4 * cm, 3.1 * cm, 2.6 * cm, 2.6 * cm, 2.6 * cm, 2.6 * cm])


def paired_table():
    pc = pd.read_csv(OUT / "paired_comparison.csv")
    pc = pc[pc["metric"] == "ECE"]
    data = [["Model", "Calibration", "Mean change in ECE", "Splits improved (of 20)"]]
    data += [[r.model, r.variant, f"{r.mean_change:+.4f}", str(r.splits_improved)] for r in pc.itertuples()]
    return styled_table(data, [4 * cm, 3.6 * cm, 4 * cm, 4 * cm])


story = [
    p("Calibrated Probability Scoring Model", S["Title"]),
    p("Machine Learning Assignment Report", S["Heading3"]),

    p("1. Objective", S["Heading2"]),
    p("Build classifiers whose scores are <i>probabilities that mean what they say</i>: among all "
      "cases scored 0.7, about 70% should truly be positive. The project compares three models, "
      "applies Platt scaling and isotonic regression, and evaluates calibration with reliability "
      "diagrams and expected calibration error (ECE)."),

    p("2. Why calibration matters", S["Heading2"]),
    p("Ranking quality (ROC-AUC) says whether risky cases score higher than safe ones. It says "
      "nothing about whether a score of 0.9 means 90% risk. Decisions often depend on the actual "
      "number: a clinic may biopsy above 20% risk, a lender prices a loan by default probability, "
      "and expected-cost calculations multiply probability by cost. A model that ranks perfectly "
      "but is badly calibrated leads to wrong thresholds and wrong cost estimates."),

    p("3. Data and method", S["Heading2"]),
    *bullets([
        "<b>Data:</b> Wisconsin Diagnostic Breast Cancer, 569 patients, 30 features, 37.3% malignant "
        "(positive class). Bundled with scikit-learn.",
        "<b>Models:</b> Logistic Regression (scaled), Random Forest (200 trees), Gaussian Naive Bayes. "
        "They are known to behave differently: logistic regression is usually well calibrated, forests "
        "tend to be under-confident, and naive Bayes tends to be over-confident.",
        "<b>Calibration:</b> scikit-learn's CalibratedClassifierCV with method 'sigmoid' (Platt) or "
        "'isotonic', fitted on out-of-fold predictions inside the training set (5 folds), so the test "
        "set never influences calibration.",
        "<b>Evaluation:</b> 20 random stratified 70/30 splits. With only 569 rows a single test set "
        "(171 rows) gives noisy calibration estimates, so metrics are averaged over splits "
        "(standard deviation in brackets).",
        "<b>Metrics:</b> ECE (10 equal-width bins), Brier score, log loss (all lower is better) and "
        "ROC-AUC. Reliability diagrams use predictions pooled over all 20 test sets, which puts more "
        "points in each bin.",
    ]),

    p("4. Results", S["Heading2"]),
    results_table(),
    p("Mean (standard deviation) over 20 splits. Lower is better for ECE, Brier and log loss.", SMALL),
    Spacer(1, 8),
    p("Calibration vs. no calibration, paired by split (ECE):", BODY),
    paired_table(),
    Spacer(1, 10),
    *figure("reliability_diagrams.png",
            "Figure 1. Reliability diagrams (top) and histograms of predicted probabilities, log scale "
            "(bottom). The dashed diagonal is perfect calibration. The ECE values in the legends are "
            "computed on pooled predictions, so they are lower than the per-split averages in the "
            "table: ECE computed on small samples is biased upward. Compare methods within one "
            "source, not across them."),
    Spacer(1, 6),
    *figure("metric_comparison.png",
            "Figure 2. ECE and Brier score before and after calibration (mean &plusmn; standard "
            "deviation over 20 splits)."),

    p("5. Findings", S["Heading2"]),
    *bullets([
        "<b>Ranking is unchanged.</b> ROC-AUC moves by less than 0.003 for every model and "
        "calibrator. Calibration changes what the numbers mean, not the order of cases.",
        "<b>Naive Bayes benefits most.</b> Its raw log loss is 0.603, driven by extreme, often wrong "
        "probabilities. Platt scaling cuts it to 0.219 and isotonic to 0.269 (improved in 19 of 20 "
        "splits for both). Isotonic also lowers ECE (0.060 to 0.045) and Brier (0.057 to 0.044).",
        "<b>Random Forest is under-confident, and isotonic fixes the middle of the range.</b> "
        "In Figure 1 the raw forest sits above the diagonal for scores above 0.5: cases scored about "
        "0.85 are malignant 97% of the time. Isotonic lowers mean ECE from 0.046 to 0.033 (better in "
        "16 of 20 splits). Platt scaling does not help (0.046 to 0.050): a sigmoid is too rigid a "
        "shape for the forest's distortion.",
        "<b>Logistic Regression is already well calibrated, and calibration can hurt.</b> "
        "Platt scaling made ECE worse in all 20 splits (0.028 to 0.063). Isotonic changed ECE by "
        "only 0.003, smaller than the split-to-split standard deviation (about 0.007 to 0.009), so I "
        "treat that as no real difference. Calibration is not a free upgrade; it should be tested.",
        "<b>Isotonic regression trades log loss for ECE.</b> It produces step functions that often "
        "output exactly 0 or 1, so a single confident mistake is penalised heavily. For the forest "
        "log loss rose from 0.143 to 0.190 even though ECE fell. Which metric matters depends on "
        "the use: ECE for trustworthy reported risk, log loss when over-confident errors are costly.",
    ]),

    p("6. Calibration in decision-making", S["Heading2"]),
    p("Two concrete cases from the pooled test predictions show why this matters:"),
    *bullets([
        "<b>Naive Bayes (uncalibrated)</b> gave 2,164 cases a probability averaging 0.001, "
        "essentially 'certainly benign'. In fact 5.5% of them were malignant, around 1 in 18. "
        "A screening rule built on 'under 1% risk, no follow-up' would miss real cancers.",
        "<b>Random Forest (uncalibrated)</b> scored 159 cases at about 0.14 when only 3.8% were "
        "malignant. Reading 0.14 literally would over-state their risk by roughly 3.7 times, "
        "leading to unnecessary follow-up if the threshold is set in risk terms.",
    ]),
    p("After isotonic calibration, the forest's cases scored about 0.14 were malignant 14.9% of the time, "
      "so the score can be read as a risk. The point: a threshold such as 'act at 20% risk' is only "
      "meaningful if the score is calibrated."),

    p("7. Recommendation", S["Heading2"]),
    p("For probability scoring on this dataset, <b>Logistic Regression without extra calibration</b> is "
      "the best choice: it has the lowest log loss (0.075) and Brier score (0.020), near-best ECE "
      "(0.028), and the highest ROC-AUC (0.995). If a tree ensemble is required, calibrate it with "
      "<b>isotonic regression</b>. Naive Bayes should always be calibrated before its "
      "probabilities are used."),

    p("8. Limitations", S["Heading2"]),
    *bullets([
        "The dataset is small and almost linearly separable, so all models are accurate and "
        "calibration gains are modest. Calibration effects would be larger on noisier data.",
        "Isotonic regression needs plenty of data; each calibrator here is fitted on only about "
        "80 held-out points (398 training rows / 5 folds), so it can overfit, which shows as jagged "
        "curves for Naive Bayes.",
        "Splits overlap, so pooled predictions are not independent, and the pooled reliability "
        "curves should be read as illustration, not as a precise estimate.",
        "ECE depends on the binning (10 equal-width bins here); a different binning shifts values.",
        "I did not investigate why Platt scaling degrades the already-calibrated logistic model; "
        "the likely explanation is that the extra fit on small out-of-fold sets adds noise.",
    ]),

    p("9. How to run", S["Heading2"]),
    Preformatted("pip install -r requirements.txt\npython main.py        # experiment, figures, CSVs\n"
                 "python make_pdf.py    # regenerate this report", CODE),
    PageBreak(),
    p("Appendix: Source code", S["Heading2"]),
]

for rel in ["main.py", "src/config.py", "src/data.py", "src/models.py", "src/metrics.py",
            "src/experiment.py", "src/plots.py"]:
    story += [p(f"<b>{rel}</b>"), Preformatted((ROOT / rel).read_text(), CODE), Spacer(1, 8)]

SimpleDocTemplate(str(OUT / "Calibration_Report.pdf"), pagesize=A4, leftMargin=2 * cm,
                  rightMargin=2 * cm, topMargin=1.8 * cm, bottomMargin=1.8 * cm,
                  title="Calibrated Probability Scoring Model").build(story)
print("PDF written")
