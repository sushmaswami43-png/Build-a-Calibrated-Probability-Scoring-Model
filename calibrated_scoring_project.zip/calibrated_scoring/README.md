# Calibrated Probability Scoring Model

Trains Logistic Regression, Random Forest and Gaussian Naive Bayes on the Wisconsin
breast-cancer data, calibrates each with Platt scaling and isotonic regression, and
evaluates calibration with reliability diagrams, ECE, Brier score and log loss over
20 random train/test splits.

    pip install -r requirements.txt
    python main.py        # runs the experiment, writes figures and CSVs to outputs/
    python make_pdf.py    # builds outputs/Calibration_Report.pdf from those results

Layout: `src/config.py` settings, `data.py` loading, `models.py` classifiers and
calibration wrapper, `metrics.py` ECE and scores, `experiment.py` repeated evaluation,
`plots.py` figures, `main.py` entry point.
